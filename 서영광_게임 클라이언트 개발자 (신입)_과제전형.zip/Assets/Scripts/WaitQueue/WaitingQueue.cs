using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

[Serializable]
public class WaitingSlot
{
    public WaitngPoint waitPoint;
    public CustomerController Customer { get; set; }
    
    public bool IsEmpty => Customer == null;

    public WaitingSlot(WaitngPoint waitPoint, CustomerController customer)
    {
        this.waitPoint = waitPoint;
        this.Customer = customer;
    }
}

public enum PayState
{
    CustomerWaiting,
    PaymentStart,
    Processing,
    PaymentCompleted,
}

public class WaitingQueue : MonoBehaviour
{
    public List<WaitingSlot> waitingSlots = new List<WaitingSlot>();
    public int maxWaitingSlotNum = 3;
    protected Queue<CustomerController> waitQueue = new Queue<CustomerController>();
    [SerializeField] protected GameObject waitPointPrefab;
    [SerializeField] protected int onePerPrice;
    public int OnePerPrice => onePerPrice;
    
    protected bool isLineQueue = false;
    public bool IsLineQueue => isLineQueue;

    public event Action UsingUpdateEvent;
    public event Action<UnitController> NewUpdateEvent;
    public event Action OpenEvent;
    
    public int  Count => waitQueue.Count;
    public bool IsFull => GetEmptyWaitingSlot() == null;

    protected virtual void Start()
    {
        //poolManager.SetPoolQueue(waitPointPrefab);
        waitQueue.Clear();
    }

    protected WaitingSlot GetEmptyWaitingSlot()
    {
        for (int i = 0; i < waitingSlots.Count; i++)
        {
            if(waitingSlots[i].IsEmpty) return waitingSlots[i];
        }
        return null;
    }
    
    public virtual WaitingSlot Enqueue(CustomerController customerController)
    {
        var waitingSlot = GetEmptyWaitingSlot();
        if (waitingSlot == null)
        {
            if (waitingSlots.Count < maxWaitingSlotNum)
            {
                PoolManager.instance.ActiveObject(waitPointPrefab).transform.TryGetComponent(out WaitngPoint waitPoint);
                waitPoint.transform.SetParent(transform);
                WaitingSlot tempWaitingSlot = new WaitingSlot(waitPoint, customerController);
                waitingSlots.Add(tempWaitingSlot);
                //waitQueue.Enqueue(tempWaitingSlot);
                waitQueue.Enqueue(customerController);
                return tempWaitingSlot;
            }

            return null;
        }
        else
        {
            waitingSlot.Customer = customerController;
            waitQueue.Enqueue(customerController);
            return waitingSlot;
        }
    }

    public CustomerController Dequeue()
    {
        return waitQueue.Dequeue();
    }

    public bool ContainCustomer(CustomerController customer)
    {
        return waitingSlots.Find(x=>x.Customer == customer) != null;
    }

    protected bool GetIsEmptyWaitingSlot()
    {
        foreach (WaitingSlot slot in waitingSlots)
        {
            if (slot.IsEmpty) return true;
        }

        return false;
    }

    public WaitingSlot GetWaitingSlotOrNullByCustomer(CustomerController customer)
    {
        foreach (WaitingSlot slot in waitingSlots)
        {
            if(slot.Customer == customer) return slot;
        }
        
        return null;
    }

    protected void PublishUsingUpdateEvent()
    {
        UsingUpdateEvent?.Invoke();
    }

    public virtual void PublishOpenEvent()
    {
        OpenEvent?.Invoke();
    }

    public virtual void PublishNewUdateEvent(UnitController unit)
    {
        NewUpdateEvent?.Invoke(unit);
    }
    
}
